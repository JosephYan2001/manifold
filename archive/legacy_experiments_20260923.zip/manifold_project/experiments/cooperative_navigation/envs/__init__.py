"""Navigation environment adapter."""
