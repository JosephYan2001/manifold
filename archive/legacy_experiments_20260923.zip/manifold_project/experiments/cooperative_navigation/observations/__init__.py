"""Local information boundary."""
