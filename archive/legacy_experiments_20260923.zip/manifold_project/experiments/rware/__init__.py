"""Warehouse experiment; implementation pending."""
