"""Pair-coordination environment implementation."""
