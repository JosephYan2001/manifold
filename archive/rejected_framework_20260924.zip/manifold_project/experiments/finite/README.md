# 有限机制实验模块

这部分迁用归档成对协作模块的优化、AN/SA、前向 KL、标签冻结与检查逻辑，并适配新版总体实验方案。运行不读取 ZIP，也不载入旧结果。全部机制计算只依赖 NumPy；文件写入复用公共报告模块。

| 文件 | 职责 |
|---|---|
| `environments.py` | 一步成对协作与两步协作的完整回合采样、独立枚举及闭式真值、MC/精确标签 |
| `numerics.py` | 统一回合权重、AN/SA 平滑有界方向优化、指数目标、前向 KL 拟合、DA 旧策略比率代理 |
| `optim.py`、`objectives.py`、`acceptance.py` | 从归档迁入并适配的 Adam、方向/Actor 目标和有界回合检查 |
| `diagnostics.py` | P-E、P-A、P-T、P-I、P-B、T-V 的固定基点机制实验 |
| `training.py` | P-L/T-L 完整源训练、独立学习基线、经验双检查、预算计数、冻结评价与 NumPy checkpoint |
| `__init__.py` | `run_experiment(experiment, config, output)` 公共接口 |

策略数组存储每种输入下选择动作 `+1` 的概率；方向系数 `c` 表示动作向量 `q=(-c,c)`。P 的状态下标为类型 `-1,+1`，T 为首步、第二步正状态、第二步负状态。全部梯度按机器人平均及归一化折扣占用计算；T 一个完整回合消耗两个联合环境步。

P-E 的 AN/SA 在同批回合、同标签、同零初始化、同平滑 `tanh` 约束和同 Adam 设置下只改变二次项。P-A 的所有拟合预算和 Actor 类别共享同一个有限样本学得的 AN 方向；受限 Actor 是在相同旧策略上只能加一个共享 logit 偏移的类。理想目标和精确投影只做诊断。

P-T 只在四人源上拟合及经验选步幅，目标真值不参与选择。实际有限拟合候选的迁移诊断沿明确的源 logit 路径进行；它不是对任意优化器参数化曲线的未经验证推断。DA 没有方向网络，不输出方向误差。

P-I 首版完成精确输入映射及损失分解，尚不包含实体网络学习。P-TB 由共享实体模块另行实现，不能用此处的自身类型表格模型冒充完整名单实验。

P-L/T-L 的 `budget` 是**每方法、每标签组**的全部源联合步数，包括 Critic 独立样本、训练、方向检查、旧新策略回报检查和选模监控。最后不足一个完整更新时保留未使用预算；不截断完整回合。固定基点实验由 `sample_sizes`、`data_seeds` 和 `evaluation_episodes` 决定样本量，不受多轮训练的 `budget` 控制。两步的精确优势组明确标注 oracle 诊断，不能和 MC 学习基线组混排名。

训练基线在独立批次上最小二乘拟合后冻结：P 为常数，T 为三个公开状态的表格值。它们是有限环境的简单 Critic，不能称为导航网络结构。采用源随机回合均值进行经验检查，不声称高置信改进。

每个训练方法/标签组最多保存 `final.npz` 和 `best_source.npz`，只含部署所需的 Actor 概率及格式标识，不伪装成 PyTorch 文件，也不是包含优化器的续训快照。主结果使用 final；best-source 仅按独立源监控回报选择。`load_policy` 可加载冻结 Actor。训练与机制表统一写 CSV，不逐轮生成 JSON/JSONL。

数值检查：在仓库根目录运行 `python -m pytest manifold_project/experiments/tests/test_finite.py -q`。

公共配置的对应关系：`labels` 中 `exact/mc/mc_zero` 分别表示精确联合优势、MC 减精确基线、零基线 MC；`learning_labels` 中的 `mc` 改为独立学习基线。`actor_fit_steps` 控制 P-T/P-L/T-L 的实际更新，`fit_steps` 列表只提供 P-A 的拟合预算轴；`source_eval_episodes` 控制参与 best-source 选择且计费的源监控，`evaluation_episodes` 控制最终纯报告评价。两者分开。`methods` 对估计实验筛选 AN/SA，对完整更新筛选 AN/SA/DA；P-A 只挑一个方向参考（AN 优先，否则 SA）以保持同一个 `q`，不把两个方向估计器混进拟合预算轴。

此 NumPy 小模型不使用应用网络的 `hidden/heads/relation_layers`、Torch 设备、PPO/GAE、熵正则或神经 Critic 优化参数。有限 Actor 采用原始 Bernoulli logit，所有方法统一仅加 `1e-12` 数值保护；应用的 `probability_floor` 不是它的训练约束。`seeds` 由总入口逐个展开为本接口的 `seed`；本接口不会内部重复所有种子。P-I/P-B 的有限映射及边界构造按方案固定，不受算法方法列表改变。

## 归档迁用清单

以下旧路径都位于 `archive/legacy_experiments_20260923.zip` 内的 `manifold_project/experiments/pair_coordination/`。迁用是实际运行依赖，不是只保留一份未调用的旧源码。

| 新位置 | 旧来源 | 保留行为 | 必要改动或未原样迁入的理由 |
|---|---|---|---|
| `optim.Adam` | `training/optim.py` | Adam 状态、偏差修正、有限性及梯度形状检查 | 仅修复旧错误信息乱码；无旧配置依赖 |
| `objectives.direction_records` | `training/direction_loss.py::record_terms` | `onehot−p` score、解析 `Fq`、SA 平方项及向量梯度 | 保留 episode/time/agent 三轴，最后将梯度收缩到 `q=(-c,c)` 系数；旧版只有 episode/agent |
| `objectives.forward_kl_and_logit_gradient`、`numerics.fit_actor` | `training/actor_fit.py` | 正向 `KL(target || Actor)`、概率/权重校验、从旧 Actor 独立副本优化 | 统一无混合概率头，增加受限共享偏移类；旧 beta 混合头的链式导数不能原封不动套到新 Actor |
| `acceptance.py`、`diagnostics.empirical_update` | `training/acceptance.py` | 完整回合均值、显式经验/界限检查、有限性及确定界校验 | 增加配置阈值；新协议回报平局可接收，显式 `inclusive=True`；部署训练始终用经验模式，未宣称完成置信预算协议 |
| `environments.labels_for` | `training/labels.py` | 先冻结 Critic、复制标签、非有限检查、标签数组只读 | 扩展到完整多步 MC 和分别标明的精确优势组 |
| `numerics.sigmoid`、方向平滑边界 | `models/actor.py`、`models/direction.py` | 稳定 sigmoid；零和 `tanh` 方向及链式导数 | 不迁旧 TableActor 配置默认值，保持新旧策略规定与 P-A 受限类一致 |
| `diagnostics.dataset_hash` | `experiments/mechanisms.py::dataset_hash` | 连续数组字节哈希，验证 AN/SA 确实共享数据 | 改字段名并增加时间形状、旧概率、权重；旧哈希不能完整标识两步批次 |
| CSV 与统计 | `experiments/reporting.py` | 紧凑 CSV、原子覆盖、配对批次统计理念 | 调用现行 `common.reporting`，不保留有限模块的重复 writer，不恢复旧 JSONL 依赖及旧编号 |
| `environments.PairGame` | `envs/pair_coordination.py`、`evaluation/exact_pair.py` | 一步联合采样、旧概率快照、独立枚举与闭式交叉核验 | 新偏置和交互权重；增加固定边权、组成变化；旧归一化公式不能用于全部目标变体 |
| `numerics.fit_direct` | `training/policy_gradient.py` | 首步使用同一 score 梯度的出发点 | 必须改写：旧实现只有一次新鲜批次 PG；新版 DA 重复更新要求旧策略比率代理，不能反复使用旧 log-prob 目标 |
| `training.train` | `training/plan.py`、旧 runner/checkpoint 组织 | 区分训练/critic/检查用途、保留旧策略与最终/最优文件 | 修正旧 PG 不计回报检查；增加两步完整回合、源监控计费，停止 oracle 选 best，不恢复旧结果/逐轮 JSONL |
| `TwoStepGame`、P-I、新版诊断组合 | 旧包无同等实现 | 复用以上优化和检查底层 | 两步时间结构、新信息映射及条件迁移协议确需新增，不能用旧一步模型冒充 |

测试还从 ZIP **只读加载选定旧函数**，比较迁用前后的方向损失/梯度、KL 和 Adam 数值；正式运行不依赖 ZIP 存在。
