"""Migrated deterministic Adam for finite tables.

Source: archive/legacy_experiments_20260923.zip ::
manifold_project/experiments/pair_coordination/training/optim.py.
Preserved optimizer, validation and state layout; repaired the legacy mojibake
error message. Kept independent of the archived training/configuration package.
"""
import numpy as np


class Adam:
    def __init__(self, shape, lr):
        if not np.isfinite(lr) or lr <= 0:
            raise ValueError("Learning rate must be positive")
        self.lr, self.t = lr, 0
        self.m, self.v = np.zeros(shape), np.zeros(shape)

    def step(self, parameters, gradient):
        if gradient.shape != parameters.shape or not np.isfinite(gradient).all():
            raise ValueError("Non-finite or incorrectly shaped gradient")
        self.t += 1
        self.m = .9 * self.m + .1 * gradient
        self.v = .999 * self.v + .001 * gradient ** 2
        update = self.lr * (self.m / (1 - .9 ** self.t)) / (np.sqrt(self.v / (1 - .999 ** self.t)) + 1e-8)
        parameters -= update
        if not np.isfinite(parameters).all():
            raise FloatingPointError("Non-finite parameters after Adam update")
