"""Selected legacy storage helpers, independent of environment and torch imports.

Migrated from archive: cooperative_navigation/training/storage.py.
seed_for and the atomic replacement/retry algorithm retain their original logic;
torch is imported only by the caller to keep finite NumPy experiments lightweight.
"""
import hashlib
import os
from pathlib import Path
import tempfile
import time


def seed_for(*parts):
    return int.from_bytes(hashlib.sha256('|'.join(map(str, parts)).encode()).digest()[:4], 'little')


def atomic(path, writer):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=path.name+'.', suffix='.tmp', dir=path.parent)
    os.close(fd)
    try:
        writer(name)
        for attempt in range(8):
            try:
                os.replace(name, path)
                break
            except PermissionError:
                if attempt == 7:
                    raise
                time.sleep(min(.05*2**attempt, .8))
    finally:
        if os.path.exists(name):
            os.unlink(name)
