# 新版实验模块

更新：2026-09-24。研究问题和实验定义见[总体实验方案](../docs/总体实验方案.md)。本文件负责代码结构、运行命令和实现差异，避免另建重复实验矩阵。

当前已实现成对、两步、实体成对、协作导航、仓库的入口及共享训练/评价。已经完成有限数值核验、真实 MPE2/RWARE 的短程训练、冻结跨人数评价和 GIF 检查；**尚未运行论文预算的训练，没有据此形成性能或收敛结论**。

## 1. 复用原则与模块结构

以旧代码迁移适配为基础：保留能够核验的优化、损失、拟合、检查、环境奖励、作者 PPO 和统计逻辑。新协议所需的实体接口、时间模型和仓库适配单独实现。正式运行不读取 ZIP，归档保持不变。

```text
experiments/
  run_experiments.py       直接脚本入口，与 python -m ... 等价
  cli.py / registry.py     实验编排、源依赖、统一参数及执行清单
  configs/                defaults、三档 profile、各环境配置
  common/                 原子保存、种子统计、总图、运行时设置
  finite/                 NumPy 成对/两步模型及精确机制实验
  applications/
    envs/                 导航、仓库和完整名单成对环境适配
    models.py             实体 Actor/方向网络及中央/本地 Critic
    training.py           AN/SA/DA 和 PPO 共用的采样、预算、检查
    ppo.py / vendor/      固定提交的作者 PPO 更新器及接口适配
    evaluation.py         冻结 Actor 评价；目标侧不建 Critic
  visualize.py            导航、仓库的冻结任务 GIF
  tests/                  有限数值、实体、原生环境和入口协议核验
  results/                用户实际运行结果，默认不进入版本控制
```

| 新位置 | 主要归档来源 | 保留与适配 |
|---|---|---|
| `finite/optim.py、objectives.py、acceptance.py` | pair 的 `training/optim.py、direction_loss.py、actor_fit.py、acceptance.py` | 迁用 Adam、AN/SA 向量计算、前向 KL 与回合检查；适配时间轴、Actor 类和新阈值协议；测试直接与归档旧函数核对数值 |
| `finite/environments.py、numerics.py、training.py` | pair 的环境、oracle、标签、Actor/方向头、PG 和 runner | 保留采样/冻结/指数目标组织；新增固定边权与两步，DA 改用规定的比率代理，best 改为独立源监控 |
| `applications/envs/navigation.py` | navigation 的 `envs/navigation.py` | 保留原生动力学、奖励均值、覆盖、碰撞、首达/期限、同步终止核验；改为完整实体列表 |
| `applications/models.py` | navigation 的 `models/__init__.py` | 迁用中央 Critic 的两层 Tanh MLP、Actor 均匀混合和方向平滑有界公式；实体关系编码/动作读取为新增 |
| `applications/training.py` | navigation 的 collector、runner、storage | 保留完整源回合、MC/GAE、快照、独立双检查和用途账单；字典实体批处理、独立拟合诊断及新存储协议需要适配 |
| `applications/ppo.py、vendor/mappo` | navigation 的 author_ppo 与 vendor | 直接调用固定作者更新器、GAE 和 ValueNorm，保留 LICENSE/UPSTREAM；只适配实体网络与批存储 |
| `common/storage.py、statistics.py、reporting.py、plotting.py` | 旧 storage、pair/navigation reporting 和 plotting | 迁用原子替换重试、bootstrap/Wilson、种子配对与分面统计；换新 ID/指标/CSV，移除旧 JSONL 与固定绩效阈值 |
| `applications/envs/pair_entities.py` | 新版有限 PairGame | 直接共用同一奖励与边权，只包装完整名单观测，避免两套成对动力学漂移 |
| `applications/envs/warehouse.py`、两步模型 | 归档没有同等实现 | 仓库调用原生 RWARE，不自写仓库动力学；两步诊断按方案新增 |

详细有限模块来源见[finite/README.md](finite/README.md)。旧固定最近 2/2 的展平网络、旧全部 suite 配置、旧结果和 oracle-best 选模规则不属于当前协议。最近 2/2 现在是同一实体网络上的信息截断对照，不能称为原旧网络完整复现。

## 2. Python 与依赖

以下命令在仓库根目录运行。已有合适的 PyTorch/CUDA 环境时，激活该环境后使用 `python`；安装列表不会主动替换已经满足条件的 PyTorch：

```powershell
python -m pip install -r manifold_project/experiments/requirements.txt
python -m pip install -r manifold_project/experiments/requirements-test.txt
```

本次已在项目内创建 `.venv`，通过 `--system-site-packages` 复用本机 PyTorch 2.7.1+cu118，并在其中安装 MPE2 1.1.1、RWARE 2.0.0。当前电脑也可用：

```powershell
.\.venv\Scripts\Activate.ps1
python -m manifold_project.experiments --list
```

环境锁定 MPE2 1.1.1、RWARE 2.0.0；每次 manifest 记录实际库版本、代码哈希、配置、设备和环境字段。仓库的 tiny ASCII 地图和 SHA256 在 `configs/warehouse.json` 中固定。

CUDA 的 `CUBLAS_WORKSPACE_CONFIG=:4096:8` 在加载模型前设置。确定性训练使用数学版 attention，不默认改成非确定性执行。以前使用的 OpenMP 兼容开关仍可通过 `--allow-duplicate-openmp` 显式打开；不会主动拒绝该模式，manifest 会记录。该开关只用于明确选择的运行，不代表重复运行库冲突已经根治。

P/T 有限模块只使用 NumPy；`--device cuda` 不会将它变成 GPU 训练。导航、仓库和 P-TB 的实体网络使用指定 Torch 设备。

## 3. 先运行哪条命令

先执行首批机制实验：

```powershell
python -m manifold_project.experiments --experiments P-E P-A P-T --profile pilot --output manifold_project/experiments/results/pair_mechanisms_pilot_v1 --plot
```

需要检查实际配置而不创建结果：

```powershell
python -m manifold_project.experiments --experiments P-E P-A P-T --profile formal --dry-run
```

`python manifold_project/experiments/run_experiments.py ...` 与上述模块命令等价。旧 `pair_coordination/run_experiments.py`、旧 P-M/N-A 等编号没有恢复，避免同名命令启动另一套协议。

| profile | 用途 | 实际起点 |
|---|---|---|
| `smoke` | 工程通路检查 | 1 数据批次/1 种子、小网络、应用期限 8、预算 256；所有输出标注 smoke，不能用于论文 |
| `pilot` | 源预实验 | 种子 40；P-E/T-V 4 数据批次；有限多轮 8,192 步；应用 2M 步 |
| `formal` | 已冻结设置后的正式运行 | 训练种子 100–104；P-E/T-V 20 数据批次；有限多轮 65,536 步；应用 20M 步 |

P-A/P-T 按 `seeds` 展开；P-E/T-V 在内部按 `data_seeds` 展开，入口不会再重复这批数据。P-I/P-B 的精确诊断只执行一次。

`--budget` 是**每方法、每训练种子、每标签组**的源决策联合步数；P-E/P-A/P-T 等固定基点实验由样本档和种子决定采样量。共同预算不意味着更新轮次相同，日志始终打印实际累计源步数和用途账单。

## 4. 各阶段命令

### 有限环境

```powershell
python -m manifold_project.experiments --experiments P-E P-A P-T --profile formal --output manifold_project/experiments/results/pair_mechanisms_formal_v1 --plot
python -m manifold_project.experiments --experiments P-I P-B P-L T-V T-L --profile pilot --output manifold_project/experiments/results/finite_learning_pilot_v1 --plot
python -m manifold_project.experiments --experiments P-TB --profile pilot --device cuda --output manifold_project/experiments/results/pair_entities_pilot_v1 --plot
```

P-TB 使用完整同伴名单、共享实体 Actor 和两动作头，源 4 人训练后冻结到 2/6 人。P-I 首版为精确有限映射和信息损失分解；不会将它标成已完成神经网络信息学习实验。

T-L 将精确标签 oracle 诊断组与 MC 学习基线组分开。默认两组各有独立预算，不能把前者混入实际经验训练排名。

### 导航源训练与冻结评价

先用一个源种子检查学习趋势，再确认共同长预算：

```powershell
python -m manifold_project.experiments --experiments N-C --profile pilot --device cuda --output manifold_project/experiments/results/nav_source_pilot_v1 --plot
python -m manifold_project.experiments --experiments N-C --profile pilot --budget 20000000 --device cuda --output manifold_project/experiments/results/nav_source_budget20m_s40_v1 --plot
```

五方法默认一起运行；可用 `--methods AN SA` 等限制本次任务。2M 是流程/数量级检查，不是收敛预算承诺；是否统一扩到 40M 按总体方案仅从源曲线判断。本版本不会自动续训到另一个预算。

确定配置后执行正式源训练，随后冻结评价；正式源训练不默认查看目标：

```powershell
python -m manifold_project.experiments --experiments N-C --profile formal --device cuda --output manifold_project/experiments/results/nav_source_formal_v1 --plot
python -m manifold_project.experiments --experiments N-T N-F N-D --profile formal --source manifold_project/experiments/results/nav_source_formal_v1 --device cuda --output manifold_project/experiments/results/nav_frozen_formal_v1 --plot
```

N-F 读取源训练在预定预算位置生成的同方向拟合诊断，不重新训练或反向挑选正式 Actor。其源评价费用在 `diagnostic_steps` 单列。N-D 只改变初始位置采样范围，不保证整个轨迹密度恒定。

### 导航输入、关系与检查消融

```powershell
python -m manifold_project.experiments --experiments N-I --profile pilot --source manifold_project/experiments/results/nav_source_pilot_v1 --device cuda --output manifold_project/experiments/results/nav_input_pilot_v1 --plot
python -m manifold_project.experiments --experiments N-R --profile pilot --device cuda --output manifold_project/experiments/results/nav_relation_pilot_v1 --plot
python -m manifold_project.experiments --experiments N-Gd N-Gr --profile pilot --device cuda --output manifold_project/experiments/results/nav_checks_pilot_v1 --plot
```

N-I 默认 AN 与 MAPPO-E，分别比较 full/summary/nearest2；提供 `--source` 时复用配置、方法和种子匹配的 N-C 完整输入 final，其他输入重新训练。不提供源目录则三种输入均训练，额外费用会实际发生。N-R 只去关系层；N-Gd/N-Gr 分别只去一项检查。检查消融按诊断需要安排，不是必须全部先跑。

从包含多项实验的源目录评价时，入口优先读 manifest 中 N-C/W-C 的 final，不把同环境消融模型混入主比较。如需专门评价消融，可用 `--checkpoints .../final.pt` 明确指定，汇总保留源输入模式、关系层、检查设置和协议字段。

### 仓库

```powershell
python -m manifold_project.experiments --experiments W-C --profile pilot --device cuda --output manifold_project/experiments/results/warehouse_source_pilot_v1 --plot
python -m manifold_project.experiments --experiments W-T W-L W-F --profile pilot --source manifold_project/experiments/results/warehouse_source_pilot_v1 --device cuda --output manifold_project/experiments/results/warehouse_frozen_pilot_v1 --plot
```

W-T 固定地图和 4 请求，只改变人数；W-L 改为请求数等于目标人数，单独成表。仓库没有“首次交付就结束”语义；在期限内持续交付。

## 5. 配置、训练与限制

配置合并顺序：`defaults.json → 环境 JSON → profile → --config 覆盖 → 命令参数`。smoke 固定使用短应用期限，属于另一个工程检查协议。未知 JSON 键、错误源人数及非法超参数会在开始前报错，避免参数拼错后静默使用默认值。

只改当前要研究的参数，覆盖文件无需复制全部默认项。例如源调参：

```json
{
  "actor_lr": 0.0003,
  "critic_lr": 0.001,
  "direction_lr": 0.0003,
  "direction_steps": 200,
  "actor_fit_steps": 200,
  "step_sizes": [0.1, 0.05, 0.01],
  "check_episodes": 16
}
```

用 `--config 路径.json` 加载。有限表格优化默认 Actor/方向学习率 0.03，应用网络默认 3e−4，Critic 1e−3；AN/SA 在对应比较组内完全共用设置。PPO 保留作者 GAE、优势标准化、ValueNorm 和熵正则；这属于完整算法比较，不能把差异全归因于 Fisher。

应用中的 `probability_floor` 是均匀混合质量 beta，每个动作的实际下界为 `beta/K`；`q_bound` 是方向分量的上界。方向采用旧版平滑 `tanh−mean` 输出，满足有界零和要求，没有照搬主稿附录中示例性的硬截断。Actor 和方向网络完全独立；当前帧版本没有 GRU、通信新增权限或目标 Critic。

采样使用完整回合。导航首次同时覆盖真终止，未成功到期也为已声明有限任务的真终止；仓库到期真终止。不会把 rollout 边界零补值称为完整 MC。预算剩余不足以安全完成下轮及预定独立检查时停止，记录未用预算；预算小到无法形成任何有效轮次则报错，不生成伪训练 final。

当前是经验检查，不是附录 B 的高置信验收系统。所有方向和候选回报数据在对象冻结后重新采集，候选与旧 Actor 的回报费用均计入源预算。源监控参与 best 选择，也计费。最终纯报告评价、拟合诊断和目标评价分别记账，不反馈模型选择。

**checkpoint 用于冻结评价，不提供断点续训命令。** NumPy 保存 Actor 表，应用保存 Actor/Critic 和部分 PPO 训练状态；没有完整的源采样器/所有优化器/RNG 续训快照，不能将载入 final 冒充等价续训。更改任务协议或源配置后使用新的输出目录。

## 6. 文件与图怎么看

每个 suite 只写一个 `manifest.json`，记录实际配置、协议、版本及完成/失败状态；没有每轮 JSONL。

- `summary.csv`：长表，一行一项指标。`mean/std`、`ci95_low/high`、`independent_units` 分别为均值/标准差、95%区间和独立种子/批次数。`method="AN - SA"` 等是配对差值，直接合并在本表，避免额外成堆 CSV。单种子区间留空。
- `training.csv`：每次更新及累计用途成本；`source_steps_total` 才是预算横轴，`round` 仅是更新编号。
- `diagnostics.csv`：该项实验的方向/拟合/精确量；固定基点和同方向实验看这个表。
- `evaluation_episodes.csv`：每个评价回合的原始任务指标。最终只报告评价在 `final_evaluation/` 内，和参与选模的源监控区分。
- `analysis.md`：运行范围、样本量和解释边界；不会自动宣布方法优越或收敛。
- `overview.png`：覆盖更新的分面总图；`--plot-every 10` 控制轮间更新，不保存每轮图片。

有限训练每方法/标签组最多 `final.npz、best_source.npz`；实体训练最多 `final.pt、best_source.pt`。best 只有发生独立源监控时才生成。主比较用 final；目标原始回合不能用于挑 best。

目录用任务含义和协议版本命名。非空输出目录会明确拒绝覆盖，改用新的 `--output`；没有自动给旧结果覆盖或混合的隐式模式。

## 7. 可视化与验证

导航或仓库 final 均可在指定人数下生成冻结执行 GIF：

```powershell
python -m manifold_project.experiments.visualize --checkpoint manifold_project/experiments/results/nav_source_pilot_v1/N-C_source_learning/full/AN_s40/final.pt --agents 6 --seed 1000000 --output manifold_project/experiments/results/nav_source_pilot_v1/replay_n6.gif
```

导航使用原生 RGB 渲染；仓库从同一原生任务状态离屏绘制货架、请求、交付点和机器人朝向，不开启原生窗口。GIF 不训练，不改任务动力学，不作为总体性能证据。

统一验证命令：

```powershell
python -m pytest manifold_project/experiments/tests -q
python -m manifold_project.experiments --experiments P-E P-A P-T P-I P-B P-L T-V T-L --profile smoke --output manifold_project/experiments/results/finite_smoke_v1 --plot
```

应用 smoke 可将相应源训练和评价 ID 同时给入口，它会先训练再评价；该便利模式用于工程检查，正式研究仍按源配置冻结后再看目标的顺序执行。
