"""Protocol tests: real gradients, complete episodes, billing and frozen transfer."""
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch
import numpy as np
import torch

from manifold_project.experiments.applications.models import EntityActor
from manifold_project.experiments.applications.training import (
    SourceCollector, discounted_labels, direction_terms, exponential_target,
    forward_kl, freeze, pack, train)
from manifold_project.experiments.applications.evaluation import evaluate_checkpoint, rollout_episode, summarize


class TinyTask:
    n_agents = 4
    horizon = 3
    self_dim = 2
    entity_dim = 4
    state_dim = 3
    action_dim = 5
    initial_done = False

    def __init__(self, n_agents=4):
        self.n_agents = n_agents
        self.t = 0

    def observation(self):
        entities = np.zeros((self.n_agents, self.n_agents, 4), np.float32)
        entities[..., 0] = 1
        entities[..., 2] = np.arange(self.n_agents)
        return {'self': np.tile([self.t / self.horizon, .25], (self.n_agents, 1)).astype(np.float32),
                'entities': entities, 'mask': np.ones((self.n_agents, self.n_agents), bool)}

    def reset(self, seed=None):
        self.t = 0
        return self.observation(), {'success': False}

    def state(self):
        return np.array([self.t / self.horizon, .2, .3], np.float32)

    def step(self, actions):
        self.t += 1
        terminal = self.t == self.horizon
        reward = float(np.mean(np.asarray(actions) == 1))
        return self.observation(), reward, terminal, False, dict(
            success=terminal, coverage=.5, mean_goal_distance=.2, collision_pairs=0,
            end_reason='success' if terminal else '')

    def close(self):
        pass

    def protocol(self):
        return {'environment': 'tiny_protocol_test', 'n_agents': self.n_agents,
                'horizon': self.horizon, 'test_only': True}


def tiny_env(_environment, _config, n_agents=None, **_kwargs):
    return TinyTask(n_agents or 4)


def tiny_config():
    return dict(seed=40, budget=48, n_agents=4, horizon=3, gamma=.9, hidden=8,
        heads=2, relation_layers=0, device='cpu', actor_lr=.002, critic_lr=.003,
        direction_lr=.002, direction_steps=2, actor_fit_steps=2, critic_steps=2,
        rollout_steps=6, minibatch_size=16, ppo_epochs=1, ppo_clip=.2,
        gae_lambda=.95, entropy_coef=.01, step_sizes=[.1], check_episodes=1,
        eval_every_steps=9, source_eval_episodes=1, evaluation_episodes=2,
        target_sizes=[2, 6], plot=False, save_fit_diagnostics=False)


class TrainingProtocols(unittest.TestCase):
    def test_mc_does_not_leak_between_episodes_and_rejects_cutoff(self):
        rewards = torch.tensor([[1.], [2.], [10.]])
        values = torch.tensor([[.5], [.7], [1.]])
        terminal = torch.tensor([False, True, True])
        advantage, target = discounted_labels(rewards, values, terminal, .9)
        torch.testing.assert_close(target, torch.tensor([[2.8], [2.], [10.]]))
        torch.testing.assert_close(advantage, target - values)
        with self.assertRaises(ValueError):
            discounted_labels(rewards, values, torch.tensor([False, True, False]), .9)

    def test_gae_lambda_one_matches_complete_mc(self):
        rewards = torch.tensor([[1., 1.], [2., 2.], [10., 10.]])
        values = torch.tensor([[.5, .2], [.7, .4], [1., .3]])
        terminal = torch.tensor([False, True, True])
        for first, second in zip(discounted_labels(rewards, values, terminal, .9),
                                 discounted_labels(rewards, values, terminal, .9, 'gae', 1.)):
            torch.testing.assert_close(first, second)

    def test_uniform_binary_an_sa_equivalence_and_forward_kl(self):
        mu = torch.full((2, 2), .5)
        q = torch.tensor([[-.6, .6], [-.6, .6]])
        actions = torch.tensor([0, 1])
        labels = torch.tensor([.3, 1.])
        torch.testing.assert_close(direction_terms(mu, q, actions, labels, 'AN'),
                                   direction_terms(mu, q, actions, labels, 'SA'))
        target = exponential_target(mu, q, .5)
        self.assertGreater(target[0, 1], mu[0, 1])
        expected = (target * (target.log() - mu.log())).sum(-1)
        torch.testing.assert_close(forward_kl(target, mu), expected)

    def test_old_actor_is_a_deep_frozen_snapshot(self):
        actor = EntityActor(2, 4, hidden=8, heads=2, relation_layers=0)
        old = freeze(actor)
        before = {key: value.clone() for key, value in old.state_dict().items()}
        with torch.no_grad():
            next(actor.parameters()).add_(1)
        self.assertTrue(all(torch.equal(before[key], value) for key, value in old.state_dict().items()))
        self.assertTrue(all(not parameter.requires_grad for parameter in old.parameters()))

    def test_inapplicable_task_metrics_are_absent_not_zero(self):
        actor = EntityActor(2, 4, hidden=8, heads=2, relation_layers=0)
        row, _ = rollout_episode(TinyTask(), actor, 50)
        self.assertIn('collision_pairs', row)
        self.assertNotIn('deliveries', row)
        self.assertNotIn('throughput', summarize([row]))

        class BareTask(TinyTask):
            def step(self, actions):
                obs, reward, terminal, truncated, _ = super().step(actions)
                return obs, reward, terminal, truncated, {'end_reason': 'one_step_complete'}

        row, _ = rollout_episode(BareTask(), actor, 50)
        result = summarize([row])
        for key in ('success', 'success_rate', 'collision_pairs', 'collisions_per_step', 'deliveries', 'throughput'):
            self.assertNotIn(key, row)
            self.assertNotIn(key, result)

    def test_all_source_purposes_are_billed_with_complete_episodes(self):
        actor = EntityActor(2, 4, hidden=8, heads=2, relation_layers=0)
        collector = SourceCollector(TinyTask(), 40, 17, .9)
        for purpose in collector.costs:
            rows, trajectories = collector.collect(actor, purpose, episodes=1)
            self.assertEqual(len(rows), 1)
            self.assertTrue(trajectories[0][-1]['terminal'])
            for step in trajectories[0]:
                step['actions'] = step['actions'].astype(np.int32)
            self.assertEqual(pack(trajectories, 'cpu', .9)['actions'].dtype, torch.int64)
        collector.collect(actor, 'train', min_steps=100)
        self.assertEqual(collector.total, 15)
        self.assertLessEqual(collector.total, 17)
        self.assertTrue(all(value > 0 for value in collector.costs.values()))

    @patch('manifold_project.experiments.applications.training.make_env', tiny_env)
    @patch('manifold_project.experiments.applications.evaluation.make_env', tiny_env)
    def test_all_five_updates_budget_checkpoints_and_frozen_scale_evaluation(self):
        with TemporaryDirectory() as root:
            for method in ('AN', 'SA', 'DA', 'MAPPO-E', 'IPPO-E'):
                directory = Path(root) / method
                result = train('navigation', method, tiny_config(), directory)
                record = result['records'][0]
                self.assertGreater(record['rounds'], 0)
                self.assertLessEqual(record['source_steps_total'], 48)
                self.assertTrue((directory / 'final.pt').exists())
                self.assertLessEqual(len(list(directory.glob('*.pt'))), 2)
                self.assertEqual(list(directory.glob('*.jsonl')), [])
                evaluation = evaluate_checkpoint(directory / 'final.pt', tiny_config(), directory / 'target')
                self.assertTrue(evaluation['frozen_actor_verified'])
                self.assertEqual([row['target_n'] for row in evaluation['records']], [4, 2, 6])
                self.assertGreater(evaluation['evaluation_steps'], 0)

    @patch('manifold_project.experiments.applications.training.make_env', tiny_env)
    def test_budget_too_small_does_not_emit_an_untrained_final(self):
        with TemporaryDirectory() as root:
            config = tiny_config()
            config['budget'] = 3
            with self.assertRaisesRegex(ValueError, 'cannot fund one complete source round'):
                train('navigation', 'AN', config, Path(root))
            self.assertFalse((Path(root) / 'final.pt').exists())

    @patch('manifold_project.experiments.applications.training.make_env', tiny_env)
    def test_fit_replay_does_not_change_training_path(self):
        with TemporaryDirectory() as root:
            config = tiny_config()
            config.update(budget=24, direction_check=False, return_check=False,
                source_eval_episodes=1, save_fit_diagnostics=False,
                fit_snapshot_fractions=[.5], fit_steps=[1, 2], fit_diagnostic_episodes=1)
            plain = train('navigation', 'AN', config, Path(root) / 'plain')
            config['save_fit_diagnostics'] = True
            replay = train('navigation', 'AN', config, Path(root) / 'replay')
            first = torch.load(plain['checkpoint'], weights_only=False)['actor']
            second = torch.load(replay['checkpoint'], weights_only=False)['actor']
            self.assertTrue(all(torch.equal(value, second[key]) for key, value in first.items()))
            self.assertGreater(replay['diagnostic_steps'], 0)
            self.assertEqual(plain['source_steps_total'], replay['source_steps_total'])


if __name__ == '__main__':
    unittest.main()
