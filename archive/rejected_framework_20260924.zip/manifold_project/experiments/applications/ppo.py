"""Thin entity-policy adapter around the pinned author's PPO update and GAE.

The upstream loss, optimizer steps, advantage normalization, ValueNorm and GAE
are unchanged. Only the policy interface and dictionary minibatch storage are
adapted. This is MAPPO-E/IPPO-E, not an unmodified upstream network.
"""
from types import SimpleNamespace
import numpy as np
import torch

from .vendor.mappo.onpolicy.algorithms.r_mappo.r_mappo import R_MAPPO
from .vendor.mappo.onpolicy.utils.shared_buffer import SharedReplayBuffer

COMMIT = "de66d7a4b23fac2513f56f96f73b3f5cb96695ac"


def _index(obs, index):
    return {key: value[index] for key, value in obs.items()}


class EntityPolicyAdapter:
    def __init__(self, actor, critic, config, local=False):
        self.actor, self.critic, self.local = actor, critic, local
        self.actor_optimizer = torch.optim.Adam(actor.parameters(), lr=config['actor_lr'], eps=1e-5)
        self.critic_optimizer = torch.optim.Adam(critic.parameters(), lr=config['critic_lr'], eps=1e-5)

    def evaluate_actions(self, share_obs, obs, _rnn, _critic_rnn, actions,
                         _masks, _available=None, _active=None):
        p = self.actor(obs)
        actions = torch.as_tensor(actions, device=p.device, dtype=torch.long).reshape(-1, 1)
        logp = p.gather(-1, actions).clamp_min(1e-12).log()
        entropy = -(p * p.clamp_min(1e-12).log()).sum(-1).mean()
        values = self.critic(obs if self.local else share_obs).reshape(-1, 1)
        return values, logp, entropy


class EntityBuffer:
    """Packed complete episodes; each reset has an explicit zero terminal mask."""
    def __init__(self, batch, values, config, normalizer):
        self.obs, self.states = batch['obs_flat'], batch['state_flat']
        self.actions = batch['actions'].reshape(-1, 1)
        self.old_logp = batch['old_logp'].reshape(-1, 1)
        self.rewards = batch['reward'].detach().cpu().numpy()[..., None]
        n_steps, n_agents = self.rewards.shape[:2]
        self.value_preds = np.zeros((n_steps + 1, n_agents, 1), np.float32)
        self.value_preds[:-1] = values.detach().cpu().numpy()[..., None]
        self.returns = np.zeros_like(self.value_preds)
        self.masks = np.ones_like(self.value_preds)
        self.masks[1:] = (~batch['terminal']).cpu().numpy()[:, None, None]
        self.active_masks = np.ones_like(self.value_preds)
        self.gamma, self.gae_lambda = config['gamma'], config['gae_lambda']
        self._use_proper_time_limits = self._use_popart = False
        self._use_valuenorm, self._use_gae, self.algo = normalizer is not None, True, 'mappo'
        # Calling the original method avoids a second implementation of GAE.
        SharedReplayBuffer.compute_returns(self, np.zeros((n_agents, 1), np.float32), normalizer)

    def feed_forward_generator(self, advantages, num_mini_batch):
        total = len(self.actions)
        # array_split retains every sample, including a smaller final minibatch.
        # This is the declared storage-only departure from fixed upstream lanes.
        for ids in np.array_split(np.random.permutation(total), num_mini_batch):
            if not len(ids):
                continue
            device_ids = torch.as_tensor(ids, device=self.actions.device)
            ones = np.ones((len(ids), 1), np.float32)
            yield (self.states[device_ids], _index(self.obs, device_ids), None, None,
                   self.actions[device_ids], self.value_preds[:-1].reshape(-1, 1)[ids],
                   self.returns[:-1].reshape(-1, 1)[ids], ones, ones,
                   self.old_logp[device_ids], advantages.reshape(-1, 1)[ids], None)


class AuthorPPO:
    def __init__(self, actor, critic, config, local=False):
        self.config = config
        self.policy = EntityPolicyAdapter(actor, critic, config, local)
        args = SimpleNamespace(clip_param=config.get('ppo_clip', .2),
            ppo_epoch=config.get('ppo_epochs', 10), num_mini_batch=1, data_chunk_length=1,
            value_loss_coef=config.get('value_coef', 1.), entropy_coef=config.get('entropy_coef', .01),
            max_grad_norm=config.get('max_grad_norm', 10.), huber_delta=config.get('huber_delta', 10.),
            use_recurrent_policy=False, use_naive_recurrent_policy=False,
            use_max_grad_norm=True, use_clipped_value_loss=config.get('ppo_value_clipping', True),
            use_huber_loss=config.get('ppo_huber_loss', True), use_popart=False,
            use_valuenorm=config.get('value_normalization', True),
            use_value_active_masks=False, use_policy_active_masks=False)
        self.trainer = R_MAPPO(args, self.policy, next(actor.parameters()).device)

    @torch.no_grad()
    def values(self, obs, states, denormalize=False):
        out = self.policy.critic(obs if self.policy.local else states)
        norm = self.trainer.value_normalizer
        if denormalize and norm is not None:
            out = torch.as_tensor(norm.denormalize(out.reshape(-1, 1)),
                                  device=out.device).reshape(out.shape)
        return out

    def update(self, batch):
        values = self.values(batch['obs_flat'], batch['state_flat']).reshape(batch['actions'].shape)
        buffer = EntityBuffer(batch, values, self.config, self.trainer.value_normalizer)
        self.trainer.num_mini_batch = max(1, int(np.ceil(len(buffer.actions) / self.config['minibatch_size'])))
        self.trainer.prep_training()
        stats = self.trainer.train(buffer)
        self.trainer.prep_rollout()
        out = {key: float(value.detach().cpu()) if torch.is_tensor(value) else float(value)
               for key, value in stats.items()}
        if not all(np.isfinite(value) for value in out.values()) or not all(
                torch.isfinite(parameter).all() for model in (self.policy.actor, self.policy.critic)
                for parameter in model.parameters()):
            raise FloatingPointError('The pinned PPO update produced nonfinite statistics or parameters.')
        with torch.no_grad():
            predicted = self.values(batch['obs_flat'], batch['state_flat'], True).cpu().numpy().reshape(-1)
            target = buffer.returns[:-1].reshape(-1)
            out['critic_mse'] = float(np.mean((target - predicted) ** 2))
            out['critic_explained_variance'] = float(1 - np.var(target - predicted) / np.var(target)) if np.var(target) > 1e-12 else float('nan')
        out['optimizer_updates'] = self.trainer.ppo_epoch * self.trainer.num_mini_batch
        return out

    def state_dict(self):
        norm = self.trainer.value_normalizer
        return dict(actor_optimizer=self.policy.actor_optimizer.state_dict(),
                    critic_optimizer=self.policy.critic_optimizer.state_dict(),
                    normalizer=None if norm is None else {key: getattr(norm, key).detach().cpu()
                        for key in ('running_mean', 'running_mean_sq', 'debiasing_term')})
