"""Shared application training, with lazy environment dependencies."""
