"""MPE2 first simultaneous coverage with native dynamics and native rewards.

Adapted from the archived cooperative_navigation/envs/navigation.py: retain its
pinned native dynamics, reward aggregation, distance/collision calculations,
synchronous terminal checks and first-arrival task semantics. Replace only the
fixed-width observation transport with the new entity interface; add protocol
metadata, initial-success reporting and the declared initial-density axis.
Observation parsing never reads critic state or another robot's velocity.
"""
from __future__ import annotations

from importlib.metadata import version

import numpy as np


class Navigation:
    self_dim = 5
    entity_dim = 6
    action_dim = 5

    def __init__(self, config, n_agents=None, render_mode=None):
        from mpe2 import simple_spread_v3
        self.package_version = version("mpe2")
        if self.package_version != "1.1.1":
            raise RuntimeError("Navigation protocol requires mpe2==1.1.1")
        self.config = dict(config)
        self.n_agents = int(n_agents if n_agents is not None else config.get("n_agents", 4))
        self.n = self.n_agents
        self.horizon = int(config.get("horizon", 200))
        self.coverage_radius = float(config.get("coverage_radius", 0.1))
        self.local_ratio = float(config.get("local_ratio", 0.5))
        self.initial_scale = float(config.get("initial_scale", 1.0))
        if self.n_agents < 1 or self.horizon < 1 or self.coverage_radius <= 0 or self.initial_scale <= 0:
            raise ValueError("Invalid navigation size, horizon, radius or initial scale")
        self.env = simple_spread_v3.parallel_env(
            N=self.n_agents, local_ratio=self.local_ratio, max_cycles=self.horizon,
            continuous_actions=False, num_agent_neighbors=None, num_landmark_neighbors=None,
            terminate_on_success=False, curriculum=False, dynamic_rescaling=False,
            render_mode=render_mode)
        self.names = self.env.possible_agents
        if any(self.env.action_space(name).n != self.action_dim for name in self.names):
            raise RuntimeError("The archived and current navigation protocols both require five native actions")
        self.state_dim = 6 * self.n_agents + 1
        self.t = 0
        self.initial_done = False
        self.end_reason = None
        self._ready = False

    @property
    def world(self):
        return self.env.unwrapped.world

    def _observation(self, raw):
        n = self.n_agents
        own = np.empty((n, self.self_dim), dtype=np.float32)
        entities = np.zeros((n, 2 * n - 1, self.entity_dim), dtype=np.float32)
        for i, name in enumerate(self.names):
            vector = np.asarray(raw[name], dtype=np.float32)
            expected = 4 + 2 * n + 4 * (n - 1)
            if vector.shape != (expected,):
                raise RuntimeError(f"Unexpected native observation shape {vector.shape}; expected {(expected,)}")
            own[i, :4], own[i, 4] = vector[:4], 1 - self.t / self.horizon
            entities[i, :n, 0] = 1
            entities[i, :n, 2:4] = vector[4:4 + 2 * n].reshape(n, 2)
            entities[i, n:, 1] = 1
            start = 4 + 2 * n
            entities[i, n:, 2:4] = vector[start:start + 2 * (n - 1)].reshape(n - 1, 2)
            entities[i, n:, 4:6] = vector[start + 2 * (n - 1):].reshape(n - 1, 2)
        return {"self": own, "entities": entities,
                "mask": np.ones((n, 2 * n - 1), dtype=bool)}

    def reset(self, seed=None):
        raw, _ = self.env.reset(seed=None if seed is None else int(seed))
        self.t, self.end_reason, self._ready = 0, None, True
        if self.initial_scale != 1:
            for entity in self.world.agents + self.world.landmarks:
                entity.state.p_pos *= self.initial_scale
            raw = {name: self.env.unwrapped.observe(name) for name in self.names}
        metrics = self.metrics()
        self.initial_done = bool(metrics["success"])
        if self.initial_done:
            self.end_reason = "success"
        return self._observation(raw), self._info(metrics)

    def state(self):
        if not self._ready:
            raise RuntimeError("reset must be called before state")
        items = [np.concatenate([a.state.p_pos, a.state.p_vel]) for a in self.world.agents]
        items += [lm.state.p_pos for lm in self.world.landmarks]
        return np.concatenate([*items, [1 - self.t / self.horizon]]).astype(np.float32)

    def metrics(self):
        positions = np.array([a.state.p_pos for a in self.world.agents])
        targets = np.array([lm.state.p_pos for lm in self.world.landmarks])
        distance = np.linalg.norm(positions[:, None, :] - targets[None, :, :], axis=-1).min(0)
        pairs = sum(np.linalg.norm(a.state.p_pos - b.state.p_pos) < a.size + b.size
                    for i, a in enumerate(self.world.agents) for b in self.world.agents[i + 1:])
        return {"success": bool((distance < self.coverage_radius).all()),
                "coverage": float((distance < self.coverage_radius).mean()),
                "mean_goal_distance": float(distance.mean()), "distance": float(distance.mean()),
                "collision_pairs": int(pairs), "collision_participations": int(2 * pairs),
                "collisions_per_agent": float(2 * pairs / self.n_agents),
                "reward_distance": float(-(1 - self.local_ratio) * distance.sum()),
                "reward_collision": float(-self.local_ratio * 2 * pairs / self.n_agents)}

    def _info(self, metrics):
        return {**metrics, "end_reason": self.end_reason, "initial_success": self.initial_done,
                "elapsed_steps": self.t, "completion_time_capped": self.t if metrics["success"] else self.horizon,
                "n_agents": self.n_agents, "entity_count": 2 * self.n_agents - 1}

    def step(self, actions):
        if not self._ready or self.end_reason is not None:
            raise RuntimeError("Task is inactive or already terminal; call reset before step")
        actions = np.asarray(actions)
        if (actions.shape != (self.n_agents,) or not np.all(np.isfinite(actions))
                or not np.all((actions >= 0) & (actions < 5) & (actions == np.floor(actions)))):
            raise ValueError("Expected one action in [0,4] per robot")
        raw, rewards, terminated, truncated, _ = self.env.step(
            {name: int(action) for name, action in zip(self.names, actions)})
        self.t += 1
        if set(rewards) != set(self.names):
            raise RuntimeError("Native MPE protocol unexpectedly removed an agent")
        # Reuse the archived synchronous-team guard: an any()-only check would
        # silently accept partially truncated teams at the deadline.
        if len(set(terminated.values())) != 1 or len(set(truncated.values())) != 1:
            raise RuntimeError("The shared team collector does not support asynchronous native endings")
        native_terminal, native_timeout = all(terminated.values()), all(truncated.values())
        if native_terminal or native_timeout != (self.t == self.horizon):
            raise RuntimeError("Native time limit differs from the declared finite task horizon")
        metrics = self.metrics()
        self.end_reason = "success" if metrics["success"] else "deadline" if self.t >= self.horizon else None
        reward = float(np.mean(list(rewards.values()), dtype=np.float64))
        if not np.isclose(reward, metrics["reward_distance"] + metrics["reward_collision"], atol=1e-6):
            raise RuntimeError("Native navigation reward differs from the pinned protocol")
        return self._observation(raw), reward, self.end_reason is not None, False, self._info(metrics)

    def protocol(self):
        return {"environment": "mpe2.simple_spread_v3", "version": self.package_version,
                "n_agents": self.n_agents, "n_landmarks": self.n_agents, "horizon": self.horizon,
                "actions": ["noop", "left", "right", "down", "up"],
                "self_fields": ["self_velocity_x", "self_velocity_y", "self_position_x", "self_position_y", "remaining_time_fraction"],
                "entity_fields": ["is_landmark", "is_peer", "relative_x", "relative_y", "communication_0", "communication_1"],
                "critic_fields": ["all_agent_positions_and_velocities", "all_landmark_positions", "remaining_time_fraction"],
                "observation": "native_full_lists_no_truncation", "local_ratio": self.local_ratio,
                "reward_aggregation": "mean_native_agent_rewards", "success": "first_simultaneous_coverage",
                "coverage_radius": self.coverage_radius, "deadline_is_terminal": True,
                "initial_position_range": [-self.initial_scale, self.initial_scale],
                "agent_radius": [float(a.size) for a in self.world.agents],
                "agent_acceleration": [a.accel for a in self.world.agents],
                "resolved_discrete_action_force": [5.0 if a.accel is None else float(a.accel) for a in self.world.agents],
                "agent_max_speed": [a.max_speed for a in self.world.agents],
                "agent_mass": [float(a.mass) for a in self.world.agents],
                "physics_dt": float(self.world.dt), "physics_damping": float(self.world.damping),
                "contact_force": float(self.world.contact_force),
                "contact_margin": float(self.world.contact_margin),
                "transport_classification": "B_empirical_extrapolation"}

    def render(self):
        return self.env.render()

    def close(self):
        self.env.close()
