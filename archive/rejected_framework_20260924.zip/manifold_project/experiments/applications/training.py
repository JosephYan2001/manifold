"""Shared source-only training with complete episodes and explicit costs.

AN/SA use independent direction and return checks; DA uses the same return
check. PPO-E calls the pinned author updater. No target environment participates
in training, stopping, step selection, or checkpoint selection.
"""
from copy import deepcopy
from pathlib import Path
import time
import numpy as np
import torch

from .envs import make_env
from .models import EntityActor, EntityDirection, Critic, LocalCritic
from .evaluation import tensor_obs, rollout_episode, summarize, write_rows
from .ppo import AuthorPPO, COMMIT


def freeze(model):
    model = deepcopy(model).eval()
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    return model


def forward_kl(target, actual):
    return (target * (target.clamp_min(1e-12).log() - actual.clamp_min(1e-12).log())).sum(-1)


def exponential_target(mu, q, step):
    return torch.softmax(mu.clamp_min(1e-12).log() + float(step) * q, -1).detach()


def direction_terms(mu, q, actions, labels, method='AN'):
    centered = q - (mu * q).sum(-1, keepdim=True)
    f = centered.gather(-1, actions.long().unsqueeze(-1)).squeeze(-1)
    curvature = (mu * centered.square()).sum(-1) if method.upper() == 'AN' else f.square()
    return 2 * labels * f - curvature


def discounted_labels(rewards, values, terminal, gamma, mode='mc', gae_lambda=.95):
    """Packed completed episodes. Values are frozen before Critic optimization."""
    if not bool(terminal[-1]):
        raise ValueError('The last MC/GAE episode is incomplete; zero bootstrap is forbidden.')
    result = torch.zeros_like(values)
    running = torch.zeros_like(values[0])
    if mode == 'mc':
        for index in reversed(range(len(rewards))):
            running = rewards[index] + gamma * running * (~terminal[index])
            result[index] = running
        return result - values, result
    if mode != 'gae':
        raise ValueError('label_mode must be mc or gae')
    for index in reversed(range(len(rewards))):
        next_value = values[index + 1] if index + 1 < len(values) else torch.zeros_like(running)
        alive = ~terminal[index]
        delta = rewards[index] + gamma * next_value * alive - values[index]
        running = delta + gamma * gae_lambda * alive * running
        result[index] = running
    return result, result + values


def pack(trajectories, device, gamma):
    flat = [step for episode in trajectories for step in episode]
    if not flat:
        return None
    obs = {key: torch.as_tensor(np.stack([step['obs'][key] for step in flat]), device=device,
                dtype=torch.bool if key == 'mask' else torch.float32) for key in flat[0]['obs']}
    actions = torch.as_tensor(np.stack([step['actions'] for step in flat]), device=device, dtype=torch.long)
    time_weights = torch.as_tensor([gamma ** step['time'] for step in flat], dtype=torch.float32, device=device)
    n_agents = actions.shape[1]
    states = torch.as_tensor(np.stack([step['state'] for step in flat]), device=device)
    mu = torch.as_tensor(np.stack([step['mu'] for step in flat]), device=device)
    weights = time_weights[:, None].expand(-1, n_agents).reshape(-1)
    weights = weights / weights.sum()
    return dict(obs=obs, obs_flat={key: value.reshape(-1, *value.shape[2:]) for key, value in obs.items()},
        state=states, state_flat=states[:, None, :].expand(-1, n_agents, -1).reshape(-1, states.shape[-1]),
        actions=actions, mu=mu, mu_flat=mu.reshape(-1, mu.shape[-1]),
        old_logp=mu.gather(-1, actions.unsqueeze(-1)).squeeze(-1).clamp_min(1e-12).log(),
        reward=torch.as_tensor([step['reward'] for step in flat], dtype=torch.float32, device=device)[:, None].expand(-1, n_agents),
        terminal=torch.as_tensor([step['terminal'] for step in flat], dtype=torch.bool, device=device),
        weights=weights, episodes=len(trajectories))


class SourceCollector:
    """Conservative horizon reservations prevent exceeding an interaction budget."""
    def __init__(self, env, seed, budget, gamma):
        self.env, self.seed, self.budget, self.gamma = env, int(seed), int(budget), gamma
        self.next_seed = self.seed * 10000000 + 10000
        self.costs = dict(train=0, direction_check=0, return_check=0, source_eval=0)
        self.episodes = 0

    @property
    def total(self):
        return sum(self.costs.values())

    def collect(self, actor, purpose, episodes=None, min_steps=None, reserve=0, seeds=None):
        rows, trajectories, spent = [], [], 0
        requested = int(episodes) if episodes is not None else 100000000
        if seeds is not None:
            requested = len(seeds)
        while len(rows) < requested and (min_steps is None or spent < min_steps):
            if self.budget - self.total - reserve < self.env.horizon:
                break
            seed = seeds[len(rows)] if seeds is not None else self.next_seed
            self.next_seed += 1
            row, trajectory = rollout_episode(self.env, actor, seed, self.gamma, collect=True)
            self.costs[purpose] += row['steps']
            spent += row['steps']
            self.episodes += 1
            row['purpose'] = purpose
            rows.append(row)
            if trajectory:
                trajectories.append(trajectory)
            # Avoid an infinite source sampler for a broken always-initial-success
            # task while preserving zero-step successes in the reported counts.
            if len(rows) >= 10000 and spent == 0:
                raise RuntimeError('10,000 zero-step episodes: source task has no decisions to train.')
        return rows, trajectories


def _sample(batch, size):
    count = len(batch['weights'])
    ids = torch.randperm(count, device=batch['weights'].device)[:min(size, count)]
    weights = batch['weights'][ids] * count / len(ids)
    obs = {key: value[ids] for key, value in batch['obs_flat'].items()}
    return ids, obs, weights


def fit_actor(old_actor, batch, target, steps, config):
    candidate = deepcopy(old_actor)
    for parameter in candidate.parameters():
        parameter.requires_grad_(True)
    candidate.train()
    optimizer = torch.optim.Adam(candidate.parameters(), lr=config['actor_lr'])
    for _ in range(int(steps)):
        ids, obs, weights = _sample(batch, config['minibatch_size'])
        loss = (forward_kl(target[ids], candidate(obs)) * weights).sum()
        optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(candidate.parameters(), config.get('max_grad_norm', 10.))
        optimizer.step()
    return candidate.eval()


def _values(critic, batch, local=False):
    values = critic(batch['obs_flat'] if local else batch['state_flat'])
    return values.reshape(batch['actions'].shape)


def _labels(critic, batch, config):
    with torch.no_grad():
        values = _values(critic, batch)
        labels, targets = discounted_labels(batch['reward'], values, batch['terminal'],
            config['gamma'], config.get('label_mode', 'mc'), config.get('gae_lambda', .95))
    batch['labels'], batch['targets'] = labels.reshape(-1), targets.reshape(-1)


def _critic_update(critic, optimizer, batch, config):
    critic.train()
    for _ in range(config.get('critic_steps', 20)):
        ids, _, weights = _sample(batch, config['minibatch_size'])
        error = critic(batch['state_flat'][ids]) - batch['targets'][ids]
        loss = (weights * error.square()).sum()
        optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(critic.parameters(), config.get('max_grad_norm', 10.))
        optimizer.step()
    critic.eval()
    with torch.no_grad():
        error = _values(critic, batch).reshape(-1) - batch['targets']
        return float((error.square() * batch['weights']).sum())


def _save(path, actor, critic, config, method, environment, source_steps, protocol, ppo=None):
    payload = dict(format='entity_experiments_v1', environment=environment, method=method,
        config=dict(config), actor_config=dict(actor.model_config), actor=actor.state_dict(),
        critic=critic.state_dict(), source_steps_total=source_steps, protocol=protocol,
        author_ppo_commit=COMMIT if ppo is not None else None)
    if ppo is not None:
        payload['ppo_training_state'] = ppo.state_dict()
    # Replace the same file; this code never emits per-round checkpoints.
    from ..common.storage import atomic
    atomic(path, lambda temporary: torch.save(payload, temporary))


def _diagnose_fit(old, q, batch, config, environment, round_index, fraction):
    """Offline replay only; returned candidates never replace the training Actor."""
    env = make_env(environment, config)
    rows, costs = [], 0
    count = int(config.get('fit_diagnostic_episodes', config.get('check_episodes', 8)))
    seeds = [int(config['seed']) * 10000000 + 8000000 + round_index * 1000 + i for i in range(count)]
    old_rows, validation = [], []
    try:
        for seed in seeds:
            row, trajectory = rollout_episode(env, old, seed, config['gamma'], collect=True)
            old_rows.append(row)
            costs += row['steps']
            if trajectory:
                validation.append(trajectory)
        valid = pack(validation, config['device'], config['gamma'])
        eta = config['step_sizes'][0]
        with torch.no_grad():
            target = exponential_target(batch['mu_flat'], q(batch['obs_flat']), eta)
            independent_target = None if valid is None else exponential_target(valid['mu_flat'], q(valid['obs_flat']), eta)
        for fit_steps in config.get('fit_steps', [1, 10, 100, 1000]):
            start = time.perf_counter()
            # Restore optimizer sampling RNG per fit budget: short runs are
            # prefixes of long runs on exactly the same frozen q and target.
            with torch.random.fork_rng(devices=[] if str(config['device']) == 'cpu' else [next(old.parameters()).device]):
                torch.manual_seed(int(config['seed']) + round_index)
                candidate = fit_actor(old, batch, target, fit_steps, config)
            fit_seconds = time.perf_counter() - start
            candidate_rows = [rollout_episode(env, candidate, seed, config['gamma'])[0] for seed in seeds]
            steps = sum(row['steps'] for row in candidate_rows)
            costs += steps
            with torch.no_grad():
                kl = float('nan') if valid is None else float((forward_kl(independent_target, candidate(valid['obs_flat'])) * valid['weights']).sum())
            rows.append(dict(round=round_index, budget_fraction=fraction, fit_steps=fit_steps,
                target_step=eta, independent_forward_kl=kl,
                source_return_gain=summarize(candidate_rows)['discounted_return'] - summarize(old_rows)['discounted_return'],
                fit_seconds=fit_seconds, candidate_evaluation_steps=steps,
                baseline_evaluation_steps=sum(row['steps'] for row in old_rows),
                diagnostic_only=True, used_for_selection=False))
    finally:
        env.close()
    return rows, costs


def train(environment, method, config, output):
    method = {'OURS': 'AN', 'MAPPO': 'MAPPO-E', 'IPPO': 'IPPO-E'}.get(method.upper(), method.upper())
    if method not in ('AN', 'SA', 'DA', 'MAPPO-E', 'IPPO-E'):
        raise ValueError(f'Unknown method {method}')
    c = dict(config)
    c.setdefault('device', 'cpu')
    c.setdefault('gamma', .99)
    c.setdefault('n_agents', 4)
    c.setdefault('minibatch_size', 512)
    c.setdefault('actor_lr', 3e-4)
    c.setdefault('critic_lr', 1e-3)
    c.setdefault('direction_lr', 3e-4)
    c.setdefault('step_sizes', [.1, .05, .01])
    c.setdefault('gae_lambda', .95)
    if int(c['n_agents']) != 4:
        raise ValueError('Application protocol v1 trains one four-agent source only.')
    from ..common.runtime import configure_torch
    configure_torch(c)
    torch.manual_seed(int(c['seed']))
    np.random.seed(int(c['seed']))
    directory = Path(output)
    directory.mkdir(parents=True, exist_ok=True)
    if any((directory / name).exists() for name in ('training.csv', 'final.pt', 'best_source.pt')):
        raise FileExistsError(f'Training outputs already exist: {directory}')
    env = make_env(environment, c)
    protocol = env.protocol()
    required_checks = (int(bool(c.get('direction_check', True)) and method in ('AN', 'SA'))
                       + 2 * int(bool(c.get('return_check', True)) and not method.endswith('-E')))
    minimum_budget = env.horizon * (1 + int(c.get('check_episodes', 8)) * required_checks)
    if int(c['budget']) < minimum_budget:
        env.close()
        raise ValueError(f'Budget {c["budget"]} cannot fund one complete source round: '
                         f'at least {minimum_budget} joint steps must be reservable for a full '
                         'episode and the configured independent checks. No checkpoint was saved.')
    device = torch.device(c['device'])
    if device.type == 'cuda':
        torch.cuda.reset_peak_memory_stats(device)
    model_config = dict(self_dim=env.self_dim, entity_dim=env.entity_dim, action_dim=env.action_dim,
        hidden=c.get('hidden', 128), heads=c.get('heads', 4), relation_layers=c.get('relation_layers', 2),
        mode=c.get('observation_mode', 'full'), probability_floor=c.get('probability_floor', 1e-5))
    actor = EntityActor(**model_config).to(device)
    local = method == 'IPPO-E'
    if local:
        critic_config = dict(model_config)
        critic_config.pop('probability_floor')
        critic = LocalCritic(**critic_config).to(device)
    else:
        critic = Critic(env.state_dim, hidden=c.get('hidden', 128)).to(device)
    ppo = AuthorPPO(actor, critic, c, local) if method.endswith('-E') else None
    protocol['training'] = dict(collection='complete_task_episodes',
        source_only=True, label='author_gae' if ppo else c.get('label_mode', 'mc'),
        critic_information='local_authorized' if local else 'centralized_training_only',
        probability_head='shared_softmax_with_uniform_mixture',
        direction_initialization='fresh_independent_network_per_update' if method in ('AN', 'SA') else 'not_applicable',
        checks='empirical_not_confidence_guarantees',
        final_checkpoint='last_source_actor', best_checkpoint='independent_source_task_metric_then_return',
        author_update_commit=COMMIT if ppo else None)
    if ppo:
        protocol['training']['ppo'] = dict(advantage_normalization=True,
            value_normalization=c.get('value_normalization', True),
            clipped_value_loss=c.get('ppo_value_clipping', True),
            huber_loss=c.get('ppo_huber_loss', True), huber_delta=c.get('huber_delta', 10.),
            value_loss_coef=c.get('value_coef', 1.), adam_eps=1e-5,
            recurrent=False, minibatches='entity_dictionary_array_split_no_dropped_tail')
    critic_optimizer = None if ppo else torch.optim.Adam(critic.parameters(), lr=c['critic_lr'])
    collector = SourceCollector(env, c['seed'], c['budget'], c['gamma'])
    rows, evaluation_rows, diagnostics = [], [], []
    diagnostic_cost = 0
    diagnostic_marks = set()
    next_eval = int(c.get('eval_every_steps', 500000))
    best_score, last_eval = -float('inf'), {}
    start_time, round_index = time.perf_counter(), 0
    try:
        while True:
            direction_check = bool(c.get('direction_check', True)) and method in ('AN', 'SA')
            return_check = bool(c.get('return_check', True)) and ppo is None
            check_episodes = int(c.get('check_episodes', 8))
            # Reserve one complete direction check and one old/new return pair.
            # Backtracking consumes additional pairs only when budget allows.
            reserve = env.horizon * check_episodes * (int(direction_check) + 2 * int(return_check))
            if collector.budget - collector.total < env.horizon + reserve:
                break
            old, old_critic = freeze(actor), freeze(critic)
            train_rows, trajectories = collector.collect(old, 'train', min_steps=int(c.get('rollout_steps', 4096)), reserve=reserve)
            batch = pack(trajectories, device, c['gamma'])
            if batch is None:
                break
            round_index += 1
            stats = dict(round=round_index, method=method, seed=c['seed'],
                train_discounted_return=summarize(train_rows).get('discounted_return', float('nan')),
                train_success=summarize(train_rows).get('success', float('nan')),
                train_episodes=len(train_rows), label_mode='author_gae' if ppo else c.get('label_mode', 'mc'),
                direction_score=float('nan'), direction_norm=float('nan'), direction_loss=float('nan'),
                train_forward_kl=float('nan'), independent_forward_kl=float('nan'),
                return_gain=float('nan'), step_size=float('nan'), backtracks=0,
                accepted=0, rejection_reason='', optimizer_updates=0)
            if ppo is not None:
                stats.update(ppo.update(batch))
                stats['accepted'], stats['rejection_reason'] = 1, 'ppo_update'
            else:
                _labels(old_critic, batch, c)
                stats['label_std'] = float(batch['labels'].std(unbiased=False))
                critic_start = time.perf_counter()
                stats['critic_mse'] = _critic_update(critic, critic_optimizer, batch, c)
                stats['critic_seconds'] = time.perf_counter() - critic_start
                stats['optimizer_updates'] += c.get('critic_steps', 20)
                valid = None
                q = None
                if method in ('AN', 'SA'):
                    direction_start = time.perf_counter()
                    qconfig = dict(model_config)
                    qconfig.pop('probability_floor')
                    q = EntityDirection(**qconfig, q_max=c.get('q_bound', 5.)).to(device)
                    optimizer = torch.optim.Adam(q.parameters(), lr=c['direction_lr'])
                    for _ in range(c.get('direction_steps', 100)):
                        ids, obs, weights = _sample(batch, c['minibatch_size'])
                        terms = direction_terms(batch['mu_flat'][ids], q(obs), batch['actions'].reshape(-1)[ids], batch['labels'][ids], method)
                        loss = -(terms * weights).sum()
                        optimizer.zero_grad()
                        loss.backward()
                        torch.nn.utils.clip_grad_norm_(q.parameters(), c.get('max_grad_norm', 10.))
                        optimizer.step()
                    q = freeze(q)
                    stats['direction_seconds'] = time.perf_counter() - direction_start
                    with torch.no_grad():
                        qvalues = q(batch['obs_flat'])
                        stats['direction_loss'] = -float((direction_terms(batch['mu_flat'], qvalues, batch['actions'].reshape(-1), batch['labels'], method) * batch['weights']).sum())
                        stats['direction_norm'] = float(qvalues.norm(dim=-1).mean())
                    if direction_check:
                        _, validation = collector.collect(old, 'direction_check', episodes=check_episodes,
                            reserve=2 * env.horizon * check_episodes * int(return_check))
                        valid = pack(validation, device, c['gamma'])
                        if valid is not None:
                            _labels(old_critic, valid, c)
                            with torch.no_grad():
                                stats['direction_score'] = float((direction_terms(valid['mu_flat'], q(valid['obs_flat']), valid['actions'].reshape(-1), valid['labels'], 'AN') * valid['weights']).sum())
                            with torch.no_grad():
                                critic_error = _values(critic, valid).reshape(-1) - valid['targets']
                                stats['critic_validation_mse'] = float((critic_error.square() * valid['weights']).sum())
                                target_variance = valid['targets'].var(unbiased=False)
                                stats['critic_explained_variance'] = float(1 - critic_error.var(unbiased=False) / target_variance) if target_variance > 1e-12 else float('nan')
                    stats['optimizer_updates'] += c.get('direction_steps', 100)
                gate = not direction_check or (np.isfinite(stats['direction_score']) and stats['direction_score'] > c.get('direction_threshold', 0.))
                if not gate:
                    stats['rejection_reason'] = 'direction_check'
                else:
                    for attempt, eta in enumerate(c['step_sizes']):
                        if return_check and collector.budget - collector.total < 2 * env.horizon * check_episodes:
                            stats['rejection_reason'] = 'budget_for_return_check'
                            break
                        fitting_start = time.perf_counter()
                        if method in ('AN', 'SA'):
                            target = exponential_target(batch['mu_flat'], qvalues, eta)
                            candidate = fit_actor(old, batch, target, c.get('actor_fit_steps', 100), c)
                            with torch.no_grad():
                                stats['train_forward_kl'] = float((forward_kl(target, candidate(batch['obs_flat'])) * batch['weights']).sum())
                                if valid is not None:
                                    target_valid = exponential_target(valid['mu_flat'], q(valid['obs_flat']), eta)
                                    stats['independent_forward_kl'] = float((forward_kl(target_valid, candidate(valid['obs_flat'])) * valid['weights']).sum())
                        else:
                            candidate = deepcopy(old)
                            for parameter in candidate.parameters():
                                parameter.requires_grad_(True)
                            # DA backtracking scales its learning rate; there is
                            # no direction, exponentiated target or PPO clipping.
                            optimizer = torch.optim.Adam(candidate.parameters(), lr=c['actor_lr'] * eta / c['step_sizes'][0])
                            for _ in range(c.get('actor_fit_steps', 100)):
                                ids, obs, weights = _sample(batch, c['minibatch_size'])
                                actions = batch['actions'].reshape(-1)[ids, None]
                                ratio = candidate(obs).gather(-1, actions).squeeze(-1) / batch['mu_flat'][ids].gather(-1, actions).squeeze(-1)
                                loss = -(ratio * batch['labels'][ids] * weights).sum()
                                optimizer.zero_grad()
                                loss.backward()
                                torch.nn.utils.clip_grad_norm_(candidate.parameters(), c.get('max_grad_norm', 10.))
                                optimizer.step()
                        stats['fit_seconds'] = stats.get('fit_seconds', 0.) + time.perf_counter() - fitting_start
                        stats['optimizer_updates'] += c.get('actor_fit_steps', 100)
                        stats['backtracks'], stats['step_size'] = attempt, eta
                        finite = all(torch.isfinite(parameter).all() for parameter in candidate.parameters())
                        if not finite:
                            stats['rejection_reason'] = 'numerical_failure'
                            continue
                        accepted = not return_check
                        if return_check:
                            seeds = list(range(collector.next_seed, collector.next_seed + check_episodes))
                            old_rows, _ = collector.collect(old, 'return_check', episodes=check_episodes,
                                seeds=seeds, reserve=env.horizon * check_episodes)
                            new_rows, _ = collector.collect(candidate, 'return_check', episodes=check_episodes, seeds=seeds)
                            if len(old_rows) != check_episodes or len(new_rows) != check_episodes:
                                raise AssertionError('Reserved return-check budget was insufficient.')
                            stats['return_gain'] = summarize(new_rows)['discounted_return'] - summarize(old_rows)['discounted_return']
                            accepted = stats['return_gain'] >= -c.get('return_tolerance', 0.)
                        if accepted:
                            actor.load_state_dict(candidate.state_dict())
                            stats['accepted'], stats['rejection_reason'] = 1, 'accepted'
                            break
                        stats['rejection_reason'] = 'return_check'
                if q is not None and method == 'AN' and c.get('save_fit_diagnostics', False):
                    for fraction in c.get('fit_snapshot_fractions', [.25, .5, 1.]):
                        final_round = collector.budget - collector.total < env.horizon + reserve
                        if fraction not in diagnostic_marks and (collector.total >= fraction * collector.budget or (fraction == 1 and final_round)):
                            new_rows, cost = _diagnose_fit(old, q, batch, c, environment, round_index, fraction)
                            for diagnostic in new_rows:
                                diagnostic.update(direction_score=stats['direction_score'], method=method,
                                    seed=c['seed'], source_steps_total=collector.total)
                            diagnostics.extend(new_rows)
                            diagnostic_cost += cost
                            diagnostic_marks.add(fraction)
                            write_rows(directory / 'diagnostics.csv', diagnostics)
            with torch.no_grad():
                p = actor(batch['obs_flat'])
                stats['policy_kl_old_to_new'] = float((forward_kl(batch['mu_flat'], p) * batch['weights']).sum())
                stats['policy_entropy'] = float((-(p * p.clamp_min(1e-12).log()).sum(-1) * batch['weights']).sum())
            if collector.total >= next_eval:
                count = int(c.get('source_eval_episodes', 100))
                if collector.budget - collector.total >= env.horizon * count:
                    monitor, _ = collector.collect(actor, 'source_eval', episodes=count)
                    for row in monitor:
                        row.update(round=round_index, source_steps_total=collector.total, method=method, seed=c['seed'])
                    evaluation_rows.extend(monitor)
                    last_eval = summarize(monitor)
                    primary = (last_eval.get('success', 0.) if environment == 'navigation' else
                               last_eval.get('throughput', 0.) if environment == 'warehouse' else
                               last_eval.get('discounted_return', -float('inf')))
                    # Task metric is primary; return is a declared tie breaker.
                    score = (primary, last_eval.get('discounted_return', -float('inf')))
                    if best_score == -float('inf') or score > best_score:
                        best_score = score
                        _save(directory / 'best_source.pt', actor, critic, c, method, environment, collector.total, protocol, ppo)
                    write_rows(directory / 'evaluation_episodes.csv', evaluation_rows)
                next_eval = collector.total + int(c.get('eval_every_steps', 500000))
            stats.update(source_steps_total=collector.total, source_train_steps=collector.costs['train'],
                source_direction_check_steps=collector.costs['direction_check'],
                source_return_check_steps=collector.costs['return_check'],
                source_eval_steps=collector.costs['source_eval'], source_episodes=collector.episodes,
                agent_decisions=collector.total * c['n_agents'],
                diagnostic_steps=diagnostic_cost, wall_seconds=time.perf_counter() - start_time,
                eval_success=last_eval.get('success', float('nan')),
                eval_discounted_return=last_eval.get('discounted_return', float('nan')),
                eval_throughput=last_eval.get('throughput', float('nan')))
            rows.append(stats)
            write_rows(directory / 'training.csv', rows)
            print(f"[{method} s{c['seed']}] round={round_index} source={collector.total}/{collector.budget} "
                  f"train_R={stats['train_discounted_return']:.4g} eval_R={stats['eval_discounted_return']:.4g} "
                  f"B={stats['direction_score']:.3g} KL={stats['policy_kl_old_to_new']:.3g} "
                  f"{stats['rejection_reason']}", flush=True)
            if c.get('plot', False) and round_index % max(1, int(c.get('plot_every', 10))) == 0:
                from ..common.reporting import plot_overview
                plot_overview(directory)
        if round_index == 0:
            raise RuntimeError('No source update round could be formed; no final checkpoint was saved.')
        _save(directory / 'final.pt', actor, critic, c, method, environment, collector.total, protocol, ppo)
    finally:
        env.close()
    record = dict(environment=environment, method=method, seed=c['seed'],
        source_steps_total=collector.total, budget=c['budget'], unused_budget=c['budget'] - collector.total,
        unused_reason='complete_episode_and_independent_check_reservation', rounds=round_index,
        actor_updates=sum(row['accepted'] for row in rows),
        diagnostic_steps=diagnostic_cost, checkpoint=str(directory / 'final.pt'),
        source_episodes=collector.episodes, agent_decisions=collector.total * c['n_agents'],
        peak_device_memory_bytes=torch.cuda.max_memory_allocated(device) if device.type == 'cuda' else 0,
        best_source_available=(directory / 'best_source.pt').exists(),
        actor_parameters=sum(parameter.numel() for parameter in actor.parameters()),
        critic_parameters=sum(parameter.numel() for parameter in critic.parameters()),
        wall_seconds=time.perf_counter() - start_time)
    record.update({f'source_{key}_steps': value for key, value in collector.costs.items()})
    return dict(records=[record], protocol=protocol, config=c, checkpoint=str(directory / 'final.pt'),
                source_steps_total=collector.total, diagnostic_steps=diagnostic_cost)
