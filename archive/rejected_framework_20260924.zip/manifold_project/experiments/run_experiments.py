"""Direct-file entry point; equivalent to python -m manifold_project.experiments."""
if __package__ in (None, ""):
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from manifold_project.experiments.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
